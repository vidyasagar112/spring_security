package com.example.Secdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
