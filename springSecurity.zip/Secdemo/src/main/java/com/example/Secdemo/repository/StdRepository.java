package com.example.Secdemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Secdemo.model.StdTuljapur;


@Repository
public interface StdRepository extends JpaRepository<StdTuljapur , Long> {

}
