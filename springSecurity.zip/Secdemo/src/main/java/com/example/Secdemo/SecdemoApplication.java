package com.example.Secdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories("com.example.Secdemo.repository")
@EntityScan("com.example.Secdemo.model")
public class SecdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecdemoApplication.class, args);
	}

}
