package com.example.Secdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Secdemo.model.StdTuljapur;
import com.example.Secdemo.repository.StdRepository;

@RestController
public class StdController {
	
	@Autowired
	private StdRepository stdrepository;

	@GetMapping("/getAllstyu")
	List<StdTuljapur>getAllStudents(){
		return stdrepository.findAll();
	}
}
